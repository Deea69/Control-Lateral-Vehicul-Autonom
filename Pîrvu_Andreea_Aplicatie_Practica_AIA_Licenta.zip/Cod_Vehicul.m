%% Parametri vehicul
m  = 1500;      % masa [kg]
Iz = 3000;      % moment de inertie yaw [kg m^2]
lf = 1.2;       % distanta CG - punte fata [m]
lr = 1.6;       % distanta CG - punte spate [m]
Cf = 19000;     % rigiditate laterala fata [N/rad]
Cr = 33000;     % rigiditate laterala spate [N/rad]
Vx = 15;        % viteza longitudinala constanta [m/s]

%% Matrici MM-ISI
A = [0, 1, Vx, 0;
     0, -(2*Cf+2*Cr)/(m*Vx), 0, -(2*Cf*lf-2*Cr*lr)/(m*Vx)-Vx;
     0, 0, 0, 1;
     0, -(2*Cf*lf-2*Cr*lr)/(Iz*Vx), 0, -(2*Cf*lf^2+2*Cr*lr^2)/(Iz*Vx)];

B = [0;
     2*Cf/m;
     0;
     2*Cf*lf/Iz];

C = [1 0 0 0;    % iesire 1 = pozitie laterala y
     0 0 1 0];   % iesire 2 = unghi yaw psi

D = [0;
     0];
sys = ss(A,B,C,D);

Ts=0.1;


%Regulator LQR

% Matrice de ponderare
Q = diag([100 1 50 1]);   % penalizeaza y, y_dot, psi, psi_dot
R = 1;                    % penalizeaza comanda delta

% Calcul castig LQR
K = lqr(A,B,Q,R);